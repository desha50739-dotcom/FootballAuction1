package com.example.footballauction

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Bg = Color(0xFF090B10)
private val Panel = Color(0xFF171B24)
private val Gold = Color(0xFFFFC857)
private val Muted = Color(0xFF9AA4B2)

data class Player(val name: String, val club: String, val position: String, val rating: Int, val price: Int)

private val players = listOf(
    Player("Lionel Messi","Inter Miami","RW",93,45), Player("Cristiano Ronaldo","Al Nassr","ST",91,42),
    Player("Kylian Mbappé","Real Madrid","ST",92,50), Player("Erling Haaland","Man City","ST",92,48),
    Player("Mohamed Salah","Liverpool","RW",90,38), Player("Kevin De Bruyne","Man City","CM",91,35),
    Player("Jude Bellingham","Real Madrid","CM",91,40), Player("Vinícius Júnior","Real Madrid","LW",91,43),
    Player("Harry Kane","Bayern","ST",91,36), Player("Luka Modrić","Real Madrid","CM",88,12),
    Player("Neymar Jr","Al Hilal","LW",89,22), Player("Sadio Mané","Al Nassr","LW",86,18),
    Player("Virgil van Dijk","Liverpool","CB",90,30), Player("Rúben Dias","Man City","CB",89,28),
    Player("Rodri","Man City","CDM",91,34), Player("Declan Rice","Arsenal","CDM",88,27),
    Player("Bukayo Saka","Arsenal","RW",88,32), Player("Phil Foden","Man City","CAM",89,31),
    Player("Son Heung-min","Tottenham","LW",88,26), Player("Robert Lewandowski","Barcelona","ST",90,25),
    Player("Pedri","Barcelona","CM",88,25), Player("Gavi","Barcelona","CM",85,19),
    Player("Thibaut Courtois","Real Madrid","GK",90,22), Player("Alisson Becker","Liverpool","GK",89,21),
    Player("Ederson","Man City","GK",88,18), Player("Achraf Hakimi","PSG","RB",87,24),
    Player("Theo Hernández","AC Milan","LB",88,26), Player("William Saliba","Arsenal","CB",87,25),
    Player("Ronald Araújo","Barcelona","CB",87,24), Player("Bruno Fernandes","Man United","CAM",88,25),
    Player("Bernardo Silva","Man City","CAM",88,24), Player("Lautaro Martínez","Inter","ST",89,30),
    Player("Antoine Griezmann","Atlético Madrid","CF",88,24), Player("Federico Valverde","Real Madrid","CM",89,32),
    Player("Cafu","Icons","RB",93,40), Player("Ronaldo Nazário","Icons","ST",96,65),
    Player("Zinedine Zidane","Icons","CAM",96,60), Player("Ronaldinho","Icons","LW",94,55),
    Player("Pelé","Icons","ST",98,80), Player("Diego Maradona","Icons","CAM",97,75),
    Player("Thierry Henry","Icons","ST",94,48), Player("David Beckham","Icons","RM",92,35),
    Player("Paolo Maldini","Icons","CB",95,55), Player("Franco Baresi","Icons","CB",93,42),
    Player("Andrés Iniesta","Legends","CM",94,45), Player("Xavi","Legends","CM",93,42),
    Player("Steven Gerrard","Legends","CM",92,38), Player("Wayne Rooney","Legends","CF",92,40),
    Player("Didier Drogba","Legends","ST",91,35), Player("Iker Casillas","Legends","GK",93,30)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("auction", MODE_PRIVATE)
        setContent {
            var screen by remember { mutableStateOf("home") }
            var mode by remember { mutableStateOf(5) }
            var budget by remember { mutableIntStateOf(100) }
            var remaining by remember { mutableIntStateOf(100) }
            var lot by remember { mutableStateOf(emptyList<Player>()) }
            var bought by remember { mutableStateOf(emptyList<Player>()) }
            var message by remember { mutableStateOf("") }
            var guess by remember { mutableStateOf<Player?>(null) }
            var guessText by remember { mutableStateOf("") }
            var score by remember { mutableIntStateOf(prefs.getInt("score", 0)) }

            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Gold,
                onBackground = Color.White, onSurface = Color.White
            )) {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    when (screen) {
                        "home" -> Home(
                            onFive = { mode=5; budget=100; remaining=100; bought= emptyList(); lot=players.shuffled().take(5); message=""; screen="auction" },
                            onEleven = { mode=11; budget=200; remaining=200; bought= emptyList(); lot=players.shuffled().take(11); message=""; screen="auction" },
                            onGuess = { guess=players.random(); guessText=""; screen="guess" },
                            score = score
                        )
                        "auction" -> AuctionScreen(mode, budget, remaining, lot, bought, message,
                            onBuy = { p ->
                                if (bought.any { it.name == p.name }) message = "اشتريت اللاعب بالفعل"
                                else if (p.price > remaining) message = "الميزانية لا تكفي لشراء ${p.name}"
                                else { remaining -= p.price; bought = bought + p; message = "تم شراء ${p.name} بنجاح!" }
                            },
                            onNew = { lot=players.shuffled().take(mode); message="" },
                            onHome = { screen="home" })
                        else -> GuessScreen(guess, guessText, score,
                            onText = { guessText=it },
                            onCheck = {
                                if (guessText.trim().equals(guess?.name, ignoreCase=true)) {
                                    score += 10; prefs.edit().putInt("score", score).apply()
                                    message = "إجابة صحيحة! +10 نقاط"
                                } else message = "حاول مرة أخرى!"
                            },
                            message = message,
                            onNext = { guess=players.random(); guessText=""; message="" },
                            onHome = { screen="home" })
                    }
                }
            }
        }
    }
}

@Composable
fun Home(onFive: () -> Unit, onEleven: () -> Unit, onGuess: () -> Unit, score: Int) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(22.dp))
        Text("FOOTBALL", color=Gold, fontSize=16.sp, fontWeight=FontWeight.Bold, letterSpacing=4.sp)
        Text("AUCTION", color=Color.White, fontSize=38.sp, fontWeight=FontWeight.Black)
        Text("كوّن فريق الأحلام… واثبت إنك خبير كورة", color=Muted, fontSize=14.sp)
        Spacer(Modifier.height(10.dp))
        MenuCard("⚽  المزاد الخماسي", "5 لاعبين عشوائيين • ميزانية 100 مليون", onFive)
        MenuCard("🏆  مزاد الـ11 لاعب", "11 لاعب عشوائي • ميزانية 200 مليون", onEleven)
        MenuCard("🕵️  خمن اللاعب", "اختبر معلوماتك الكروية واجمع النقاط", onGuess)
        Spacer(Modifier.weight(1f))
        Text("أفضل نتيجة تخمين: $score نقطة", color=Gold, fontWeight=FontWeight.Bold)
        Text("يعمل بدون إنترنت • نسخة تجريبية قابلة للتوسيع", color=Muted, fontSize=11.sp)
    }
}

@Composable
fun MenuCard(title: String, subtitle: String, action: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { action() }, colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
            Text(title, color=Gold, fontSize=19.sp, fontWeight=FontWeight.Bold)
            Text(subtitle, color=Muted, fontSize=13.sp)
        }
    }
}

@Composable
fun AuctionScreen(mode: Int, budget: Int, remaining: Int, lot: List<Player>, bought: List<Player>, message: String,
                  onBuy: (Player)->Unit, onNew: ()->Unit, onHome: ()->Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Text("المزاد • $mode لاعبين", color=Gold, fontSize=21.sp, fontWeight=FontWeight.Bold)
            TextButton(onClick=onHome) { Text("الرئيسية", color=Muted) }
        }
        Text("ميزانيتك المتبقية: $remaining / $budget مليون", color=Gold, fontWeight=FontWeight.Bold)
        LinearProgressIndicator(progress={ remaining.toFloat()/budget }, modifier=Modifier.fillMaxWidth().padding(vertical=10.dp), color=Gold, trackColor=Panel)
        if (message.isNotBlank()) Text(message, color=Gold, fontSize=13.sp)
        LazyColumn(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(lot) { p ->
                Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment=Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(3.dp)) {
                            Text(p.name, fontWeight=FontWeight.Bold, fontSize=16.sp)
                            Text("${p.club} • ${p.position} • تقييم ${p.rating}", color=Muted, fontSize=12.sp)
                            Text("${p.price} مليون", color=Gold, fontWeight=FontWeight.Bold)
                        }
                        Button(onClick={onBuy(p)}, colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Bg)) { Text(if (bought.any{it.name==p.name}) "تم" else "شراء") }
                    }
                }
            }
        }
        Text("اللاعبون الذين اشتريتهم: ${bought.size}", color=Gold, fontWeight=FontWeight.Bold)
        if (bought.isNotEmpty()) Text(bought.joinToString(" • ") { it.name }, color=Muted, fontSize=12.sp)
        Button(onClick=onNew, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Bg)) { Text("مزاد عشوائي جديد") }
    }
}

@Composable
fun GuessScreen(player: Player?, text: String, score: Int, onText:(String)->Unit, onCheck:()->Unit, message:String, onNext:()->Unit, onHome:()->Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement=Arrangement.spacedBy(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            Text("خمن اللاعب", color=Gold, fontSize=23.sp, fontWeight=FontWeight.Bold)
            TextButton(onClick=onHome) { Text("الرئيسية", color=Muted) }
        }
        Text("النقاط: $score", color=Gold, fontWeight=FontWeight.Bold)
        Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text("🔎  تلميحات اللاعب", color=Gold, fontWeight=FontWeight.Bold)
                Text("المركز: ${player?.position ?: "؟"}")
                Text("النادي / الفريق: ${player?.club ?: "؟"}")
                Text("التقييم: ${player?.rating ?: "؟"}")
                Text("القيمة في المزاد: ${player?.price ?: "؟"} مليون")
            }
        }
        OutlinedTextField(value=text, onValueChange=onText, modifier=Modifier.fillMaxWidth(), label={Text("اكتب اسم اللاعب")}, singleLine=true)
        Button(onClick=onCheck, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Gold, contentColor=Bg)) { Text("تحقق من الإجابة") }
        if (message.isNotBlank()) Text(message, color=Gold, fontWeight=FontWeight.Bold)
        OutlinedButton(onClick=onNext, modifier=Modifier.fillMaxWidth()) { Text("لاعب جديد") }
        Text("كل إجابة صحيحة = 10 نقاط", color=Muted, fontSize=12.sp)
    }
}
